# WIGAF
WhenIsGood Autofiller using GCal
